package com.mycompany.registroqr;

import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RegistroVisitantes {

    public RegistroVisitantes() {
        // FORMULARIO PARA ROL DE VISITANTES
        JFrame Interfaz = new JFrame("Registro Visitantes");
        Interfaz.setSize(400, 790);
        Interfaz.setLocationRelativeTo(null);
        Interfaz.setResizable(false);

        // Icono pequeño universidad (usando la segunda imagen como logo)
        Interfaz.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());

        // ----> Panel con imagen de fondo <----
        JPanel panelConImagen = new JPanel() {
            private Image imagenFondo;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    // Cargar la imagen de fondo
                    imagenFondo = ImageIO.read(new File("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\verde.jpg"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (imagenFondo != null) {
                    g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        panelConImagen.setLayout(null);
        panelConImagen.setPreferredSize(new Dimension(350, 1100)); // Ajustar el tamaño para que permita scroll (aumentar el alto si es necesario)

        //----> Titulo <----
        JLabel Titulo1 = new JLabel("Registro de Acceso", SwingConstants.CENTER);
        Titulo1.setFont(new Font("Playfair Display", Font.BOLD, 25));
        Titulo1.setFocusable(false);
        Titulo1.setForeground(Color.WHITE);
        Titulo1.setBounds(0, 160, 370, 50);
        panelConImagen.add(Titulo1);

        //----> Titulo_2 <----
        JLabel Titulo2 = new JLabel("Visitantes UCP", SwingConstants.CENTER);
        Titulo2.setFont(new Font("Playfair Display", Font.BOLD, 25));
        Titulo2.setFocusable(false);
        Titulo2.setForeground(Color.WHITE);
        Titulo2.setBounds(0, 205, 370, 30);
        panelConImagen.add(Titulo2);

        // TIPOS DE IDENTIFICACION
        JLabel subTitulo1 = new JLabel("Tipo de identificación");
        subTitulo1.setFont(new Font("Roboto", Font.BOLD, 20));
        subTitulo1.setBounds(80, 270, 370, 20);
        subTitulo1.setForeground(Color.WHITE);
        panelConImagen.add(subTitulo1);

        String[] opciones1 = {"C.C", "T.I", "C.C Extranjero", "Pasaporte", "N.I.T"};
        JComboBox<String> comboBox1 = new JComboBox<>(opciones1);
        comboBox1.setBounds(80, 300, 200, 25);
        comboBox1.setFont(new Font("Roboto", Font.BOLD, 15));
        panelConImagen.add(comboBox1);

        // NUMERO DE IDENTIFICACION
        JLabel subTitulo2 = new JLabel("Número de identificación");
        subTitulo2.setFont(new Font("Roboto", Font.BOLD, 20));
        subTitulo2.setBounds(80, 350, 370, 20);
        subTitulo2.setForeground(Color.WHITE);
        panelConImagen.add(subTitulo2);

        JTextField campoTexto1 = new JTextField();
        campoTexto1.setBounds(80, 380, 200, 25);
        campoTexto1.setFont(new Font("Roboto", Font.BOLD, 15));
        campoTexto1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent e) {
                String tipoSeleccionado = (String) comboBox1.getSelectedItem();
                char c = e.getKeyChar();              

                switch (tipoSeleccionado) {
                    case "C.C":
                        if (!Character.isDigit(c) || campoTexto1.getText().length() >= 10) {
                            e.consume(); // Ignorar entrada no válida
                        }
                    case "T.I":
                        if (!Character.isDigit(c) || campoTexto1.getText().length() >= 10) {
                            e.consume(); // Ignorar entrada no válida
                        }
                    case "Pasaporte":
                        if (!Character.isDigit(c) || campoTexto1.getText().length() >= 10) {
                            e.consume(); // Ignorar entrada no válida
                        }
                    case "C.C Extranjero":
                        if (!Character.isDigit(c) || campoTexto1.getText().length() >= 10) {
                            e.consume(); // Ignorar entrada no válida
                        }
                    case "N.I.T":
                        if ((!Character.isDigit(c) && c != '-') || campoTexto1.getText().length() >= 11) {
                            e.consume(); // Ignorar cualquier entrada no válida
                        }
                        break;
                }
            }
        });
        campoTexto1.addActionListener(e -> campoTexto1.transferFocus());
        panelConImagen.add(campoTexto1);

        // NOMBRE COMPLETO
        JLabel subTitulo3 = new JLabel("Nombre completo");
        subTitulo3.setFont(new Font("Roboto", Font.BOLD, 20));
        subTitulo3.setBounds(80, 430, 370, 20);
        subTitulo3.setForeground(Color.WHITE);
        panelConImagen.add(subTitulo3);

        // campo de texto 2
        JTextField campoTexto2 = new JTextField();
        campoTexto2.setBounds(80, 460, 200, 25);
        campoTexto2.setFont(new Font("Roboto", Font.BOLD, 15));

// Limitar a 50 caracteres y formato de texto
        campoTexto2.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                char c = e.getKeyChar();

                // Bloquear caracteres no permitidos y limitar a 50 caracteres
                if ((!Character.isLetter(c) && !Character.isSpaceChar(c)) || campoTexto2.getText().length() >= 50) {
                    e.consume(); // Bloquea el carácter si no es letra, espacio, o excede 50 caracteres
                }
            }

            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                String texto = campoTexto2.getText();
                StringBuilder textoModificado = new StringBuilder();
                boolean convertirMayuscula = true;

                for (int i = 0; i < texto.length(); i++) {
                    char c = texto.charAt(i);
                    if (Character.isLetter(c)) {
                        if (convertirMayuscula) {
                            textoModificado.append(Character.toUpperCase(c)); // Primera letra en mayúscula
                        } else {
                            textoModificado.append(Character.toLowerCase(c)); // Resto en minúscula
                        }
                        convertirMayuscula = false;
                    } else {
                        textoModificado.append(c); // Mantener el carácter si es espacio
                    }
                    if (Character.isSpaceChar(c)) {
                        convertirMayuscula = true; // Convertir siguiente letra a mayúscula después de un espacio
                    }
                }

                campoTexto2.setText(textoModificado.toString());
            }
        });

//Visitantes
        campoTexto2.addActionListener(e -> campoTexto2.transferFocus());

        panelConImagen.add(campoTexto2);

        // LUGAR QUE SE DIRIGE
        JLabel subTitulo4 = new JLabel("Lugar al que se dirige");
        subTitulo4.setFont(new Font("Roboto", Font.BOLD, 20));
        subTitulo4.setBounds(80, 510, 370, 20);
        subTitulo4.setForeground(Color.WHITE);
        panelConImagen.add(subTitulo4);

        // Definimos el arreglo bidimensional con nombres y códigos
        String[][] opciones2 = {
            {"Áreas Administrativas", "AA 1"},
            {"Secretaria General", "SG 2"},
            {"Rectoría", "REC 3"},
            {"Admisiones y Registro Académico", "ARA 4"},
            {"Dirección Administrativa y Financiera", "DAF 5"},
            {"Vicerrectoría Académica", "VA 6"},
            {"Vicerrectoría de Proyecto de Vida", "VPV 7"},
            {"Biblioteca", "BIB 8"},
            {"CIE", "CIE 9"},
            {"Cafeterías", "CAF 10"},
            {"Centro de Atención Psicológica (CAPSI)", "CAPSI 11"},
            {"Coordinación de Comunicaciones", "CC 12"},
            {"Oficina Gestión de Mercadeo", "OGM 13"},
            {"Gestión del Talento Humano", "GTH 14"},
            {"Otros", "OTR 15"}
        };

        // Extraemos solo los nombres para el JComboBox
        String[] ListaTipos = new String[opciones2.length];
        for (int i = 0; i < opciones2.length; i++) {
            ListaTipos[i] = opciones2[i][0]; // Extraemos solo el nombre
        }

        // Creamos el JComboBox utilizando solo los nombres
        JComboBox<String> comboBox2 = new JComboBox<>(ListaTipos);

        comboBox2.setBounds(80, 540, 200, 25);
        comboBox2.setFont(new Font("Roboto", Font.BOLD, 15));
        panelConImagen.add(comboBox2);

        // MOTIVO DE VISITA
        JTextArea subTitulo5 = new JTextArea("Especifique su razón de \nvisita a la Universidad");
        subTitulo5.setEditable(false);
        subTitulo5.setBackground(new Color(0, 0, 0, 0)); // Fondo transparente
        subTitulo5.setForeground(Color.WHITE); // color del texto
        subTitulo5.setFont(new Font("Roboto", Font.BOLD, 19));
        subTitulo5.setLineWrap(true); // Permite el ajuste de línea
        subTitulo5.setWrapStyleWord(true); // Ajusta palabras completas
        subTitulo5.setBounds(80, 590, 370, 50);
        subTitulo5.setFocusable(false);
        subTitulo5.setBorder(null);
        subTitulo5.setOpaque(false);
        panelConImagen.add(subTitulo5);

        JTextField campoTexto3 = new JTextField();
        campoTexto3.setBounds(80, 640, 200, 25);
        campoTexto3.setFont(new Font("Roboto", Font.BOLD, 15));
        panelConImagen.add(campoTexto3);

        // Añadir un espacio al final del panel para el QR
        JLabel ImagenQR = new JLabel();
        ImagenQR.setBounds(85, 825, 230, 230); // Ajustar el tamaño
        ImageIcon defaultImageIcon = new ImageIcon(""); // Cambia esta ruta a tu imagen por defecto NO CREO QUE SEA NECESARIO
        Image defaultImage = defaultImageIcon.getImage().getScaledInstance(230, 230, Image.SCALE_SMOOTH); // Aseguramos que la imagen se ajuste bien
        defaultImageIcon = new ImageIcon(defaultImage);
        ImagenQR.setIcon(defaultImageIcon);
        panelConImagen.add(ImagenQR);

        //----> Botón para registrar <----
        JButton botonIngresar = new JButton("Registrar/Actualizar");
        botonIngresar.setBounds(0, 685, 190, 60);
        botonIngresar.setFont(new Font("Playfair Display", Font.BOLD, 15));
        botonIngresar.setBackground(new Color(0, 128, 78));
        botonIngresar.setForeground(Color.WHITE);
        botonIngresar.setBorder(null);
        botonIngresar.setFocusPainted(false);
        panelConImagen.add(botonIngresar);

        //----> Botón para generar código QR <----
        JButton botonQR = new JButton("Generar Código");
        botonQR.setBounds(190, 685, 190, 60);
        botonQR.setFont(new Font("Playfair Display", Font.BOLD, 20));
        botonQR.setBackground(new Color(216, 49, 53));
        botonQR.setForeground(Color.WHITE);
        botonQR.setBorder(null);
        botonQR.setFocusPainted(false);
        panelConImagen.add(botonQR);

        //----> Acción al presionar Enter en el campo de identificación <----
        campoTexto1.addActionListener(e -> {
            String numeroID = campoTexto1.getText();
            boolean encontrado = false;

            for (String visitante : RegistroQR.VisitantesDB) {
                // Divide los datos del visitante en sus partes y verifica que el formato sea correcto
                String[] datos = visitante.split(", ");
                if (datos.length >= 5) {
                    // Asigna los valores directamente sin etiquetas
                    String tipo = datos[0];
                    String idGuardado = datos[1];
                    String nombre = datos[2];
                    String area = datos[3];
                    String motivo = datos[4];

                    // Compara el ID guardado con el ingresado
                    if (idGuardado.equals(numeroID)) {
                        // Rellena los campos con los datos encontrados
                        comboBox1.setSelectedItem(tipo);
                        campoTexto2.setText(nombre);
                        comboBox2.setSelectedItem(area);
                        campoTexto3.setText(motivo);

                        // Deshabilita los campos de edición para evitar cambios accidentales
                        comboBox1.setEnabled(false);
                        campoTexto2.setEditable(false);
                        comboBox2.setEnabled(false);
                        comboBox2.setBackground(new Color(220, 220, 220));
                        botonIngresar.setEnabled(false);

                        // Muestra un mensaje indicando que el visitante ya está registrado
                        JOptionPane.showMessageDialog(Interfaz, "Visitante ya registrado. Puede actualizar los datos.", "Registro encontrado", JOptionPane.INFORMATION_MESSAGE);
                        encontrado = true;
                        break;
                    }
                } else {
                    // Mensaje en consola si el formato de datos es incorrecto
                    System.out.println("Formato incorrecto en la línea: " + visitante);
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(Interfaz, "Visitante no encontrado. Puede registrar uno nuevo.", "No encontrado", JOptionPane.INFORMATION_MESSAGE);

                // Habilita campos y botón en caso de no encontrar el visitante
                campoTexto2.setEditable(true);
                comboBox2.setEnabled(true);
                comboBox2.setBackground(Color.WHITE);
                campoTexto3.setEditable(true);
                botonIngresar.setEnabled(true);
            }
        });

//----> Acción al presionar el botón "Registrar/Actualizar" <----
        botonIngresar.addActionListener(e -> {
            String tipoID = (String) comboBox1.getSelectedItem();
            String numeroID = campoTexto1.getText();
            String nombre = campoTexto2.getText();
            String area = (String) comboBox2.getSelectedItem();
            String motivo = campoTexto3.getText();

            // Validación de campos vacíos
            if (numeroID.isEmpty() || nombre.isEmpty() || area.isEmpty() || motivo.isEmpty()) {
                JOptionPane.showMessageDialog(Interfaz, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                boolean existe = false;

                // Obtener la fecha y hora actuales
                LocalDateTime fechaHora = LocalDateTime.now();
                DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm:ss");
                String fechaStr = fechaHora.format(formatoFecha);
                String horaStr = fechaHora.format(formatoHora);

                for (int i = 0; i < RegistroQR.VisitantesDB.size(); i++) {
                    String visitante = RegistroQR.VisitantesDB.get(i);
                    String[] datos = visitante.split(", ");
                    if (datos.length >= 2) {
                        String idGuardado = datos[1];

                        // Si el ID coincide, actualizamos solo el área, motivo y la fecha/hora
                        if (idGuardado.equals(numeroID)) {
                            String nuevoRegistro = tipoID + ", " + idGuardado + ", " + nombre + ", " + area + ", " + motivo + ", " + fechaStr + ", " + horaStr;
                            RegistroQR.VisitantesDB.set(i, nuevoRegistro); // Actualiza el registro en el ArrayList
                            ArchivoPlano.guardarVisitantes(nuevoRegistro); // Actualiza el registro en el archivo
                            existe = true;
                            break;
                        }
                    }
                }

                if (!existe) {
                    // Guarda nuevo visitante en el ArrayList y en el archivo en formato sin etiquetas, con fecha y hora
                    String datosVisitante = tipoID + ", " + numeroID + ", " + nombre + ", " + area + ", " + motivo + ", " + fechaStr + ", " + horaStr;
                    RegistroQR.VisitantesDB.add(datosVisitante);
                    ArchivoPlano.guardarVisitantes(datosVisitante);
                }

                // Limpia y habilita campos para el siguiente ingreso
                comboBox1.setSelectedIndex(0);
                campoTexto1.setText("");
                campoTexto2.setText("");
                comboBox2.setSelectedIndex(0);
                campoTexto3.setText("");
                campoTexto2.setEditable(true);
                comboBox2.setEnabled(true);
                comboBox2.setBackground(Color.WHITE);
                botonIngresar.setEnabled(true);

                // Mensaje de confirmación
                JOptionPane.showMessageDialog(Interfaz, "Visitante registrado/actualizado correctamente.");

                // Habilita el botón "Generar Código" después de registrar o actualizar
                botonQR.setEnabled(true);
            }
        });

        botonQR.addActionListener(e -> {
            String numeroID = campoTexto1.getText();
            String nombre = campoTexto2.getText();
            String programa = (String) comboBox2.getSelectedItem();

            // Comprobar si el estudiante está registrado
            boolean encontrado = false;
            for (String estudiantes : RegistroQR.VisitantesDB) {
                String[] datos = estudiantes.split(", ");
                if (datos.length > 1) {  // Verifica que haya más de 1 elemento en 'datos'
                    String idGuardado = datos[1];
                    if (idGuardado.equals(numeroID)) {
                        encontrado = true;
                        break;
                    }
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(Interfaz, "El estudiante no está registrado, no se puede generar el QR.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (numeroID.isEmpty() || nombre.isEmpty() || programa == null) {
                JOptionPane.showMessageDialog(Interfaz, "Debe completar los campos antes de generar el QR.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(Interfaz, "Generando código QR para: " + nombre);
                botonQR.setEnabled(false);  // Deshabilitar botón 
                String nombreQR = ("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\QRS" + numeroID + ".png");

                try {
                    nombreQR = GeneradorQR.inicioQR(numeroID); // Llamada al método
                } catch (WriterException | IOException | NotFoundException a) {
                    a.printStackTrace();
                }

                ImageIcon imageIcon = new ImageIcon(nombreQR);
                Image image = imageIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                imageIcon = new ImageIcon(image);
                ImagenQR.setIcon(imageIcon);

                // Temporizador de 2 minutos para eliminar el QR si no es leído
                ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

                String QR = nombreQR;

                scheduler.schedule(() -> {
                    // Verificar si el QR aún existe y eliminarlo
                    if (GeneradorQR.borrarQR(QR)) {
                        ImagenQR.setIcon(null); // Quitar el QR de la pantalla
                        JOptionPane.showMessageDialog(Interfaz, "Se acabó el tiempo de uso para su QR, por favor genere otro.");
                    }
                    botonQR.setEnabled(true);
                }, 30, TimeUnit.SECONDS); // Tiempo de vida del QR (2 minutos)

            }
        });

        // Crear JScrollPane y agregar el panel con imagen dentro de él
        JScrollPane scrollPane = new JScrollPane(panelConImagen);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // Desactivamos el scroll horizontal

        // Agregar el JScrollPane al JFrame
        Interfaz.setContentPane(scrollPane);

        // Hacer visible la ventana
        Interfaz.setVisible(true);
    }

}