
package com.mycompany.registroqr;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class Ingreso_salida {
    
    
    public static void GuardarClientes() {
        
        try (FileWriter BasedeDatosClientes = new FileWriter(RegistroQR.IngresosSalidasDB)) {
            //Borro todos los clientes
            BasedeDatosClientes.write("");
        } catch (IOException e) {
            System.out.println("Error al intentar actualizar el archivo de Clientes: " + e.getMessage());
        }

        //Carga el archivo con la informacion desde el ArrayList
        try (PrintWriter BasedeDatosClientes = new PrintWriter(new FileWriter(RegistroQR.IngresosSalidasDB, true))) {
            //Leo cada clientes de ClienteDB y lo guardo en el archivo fisico
            for (String datosUsuario : RegistroQR.IngresosSalidas) {
                String[] datos = datosUsuario.split(", ");
                BasedeDatosClientes.println(datos[0] + "," + datos[1] + "," + datos[2] + "," + datos[3]);
            }
            BasedeDatosClientes.close(); //Cierro el archivo de texto
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar los datos del Cliente: " + e.getMessage());
        }
    }

    //Permite leer la base de datos del clientes y cargar los datos en IngresosSalidas (el ArrayList)
    public static void CargarBD() {
        //Abro el archivo para verificar si está vacío
        File archivo = new File(RegistroQR.IngresosSalidasDB);
        if (archivo.length() != 0) { //Si no está vacío, leo y armo cada linea como una lista y la agrego a ArrayList

            //Leo el archivo plano para cargar los clientes en IngresosSalidas
            try (BufferedReader lector = new BufferedReader(new FileReader(RegistroQR.IngresosSalidasDB))) {
                //Creamos una lista con los valores de cada objeto, separados por , (coma)
                String linea;
                while ((linea = lector.readLine()) != null) {
                    String[] datos = linea.split(",");

                    //Creamos una lista con los valores de los atributos de clientes, separados por , (coma)
                    String cliente = String.format("%s, %s, %s, %s", datos[0], datos[1], datos[2], datos[3]);

                    //Agrego el registro al ArrayList
                    RegistroQR.IngresosSalidas.add(cliente);
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al leer el archivo: " + e.getMessage());
            }
        }
    }   
    
}
