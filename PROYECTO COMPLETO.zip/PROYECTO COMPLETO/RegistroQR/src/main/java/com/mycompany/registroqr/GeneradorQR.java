package com.mycompany.registroqr;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.NotFoundException;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GeneradorQR {

    private static final String ARCHIVO_REGISTRO = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt"; // Archivo de texto
    public static int PosicionID;
    public static List<String> RegistroID = new ArrayList<>();

    public static String inicioQR(String id) throws WriterException, IOException, NotFoundException {
        // Simulación: Generar y leer el QR
        String idUsuario = id; // Identificación
        // Generación del QR
        LocalDateTime currentDateTime = LocalDateTime.now();
        String fecha = currentDateTime.toLocalDate().toString();
        String horaEntrada = currentDateTime.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"));

        String QRexiste = ("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\QRS" + id + ".png");

        String nombreQR = QRexiste;

        File archivo = new File(QRexiste);
        if (archivo.exists()) {

            // Segunda lectura (Salida)
            System.out.println("Segunda lectura (salida): ");
            manejarLecturaQR(nombreQR, idUsuario, fecha, false);
            RegistroQR.help = false;
            String horaSalida = currentDateTime.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"));
            RegistroID = BuscarID(idUsuario, PosicionID);
            String Salida = String.format("%s, %s, %s, %s",
                    idUsuario, RegistroID.get(1), RegistroID.get(2), horaSalida
            );
            RegistroQR.IngresosSalidas.remove(PosicionID);
            RegistroQR.IngresosSalidas.add(Salida);
            System.out.println(RegistroQR.IngresosSalidas);
            Ingreso_salida.GuardarClientes();

        } else {
            nombreQR = Genera_QR(idUsuario, fecha, horaEntrada);
            // Primera lectura (Entrada)
            System.out.println("Primera lectura (entrada): ");
            manejarLecturaQR(nombreQR, idUsuario, fecha, true);
            RegistroQR.help = true;

            String Ingreso = String.format("%s, %s, %s, %s",
                    idUsuario, fecha, horaEntrada, "*"
            );

            RegistroQR.IngresosSalidas.add(Ingreso);
            System.out.println(RegistroQR.IngresosSalidas);
            Ingreso_salida.GuardarClientes();

        }
        return nombreQR;
    }

    // Método para manejar la primera y segunda lectura del QR
    public static void manejarLecturaQR(String nombreQR, String id, String fecha, boolean esEntrada) throws IOException, NotFoundException {
        String qrContenido = Leer_QR(nombreQR);
        if (qrContenido != null) {
            LocalTime horaActual = LocalTime.now();
            String horaEntrada = horaActual.format(DateTimeFormatter.ofPattern("HH:mm"));
            if (esEntrada) {
                // Almacenar información de entrada
                guardarEnArchivo(id, fecha, horaEntrada);
                JOptionPane.showMessageDialog(null, "Entrada exitosa: " + id);
            } else {
                // Almacenar información de salida
                String horaSalida = horaActual.format(DateTimeFormatter.ofPattern("HH:mm"));
                actualizarSalidaArchivo(id, horaSalida);
                JOptionPane.showMessageDialog(null, "Salida exitosa, vuelva pronto " + id);
                borrarQR(nombreQR); // Eliminar QR tras la salida
            }
        } else {
            System.out.println("Error: No se pudo leer el QR.");
        }
    }

// Guardar información en archivo (primera lectura: entrada)
    public static void guardarEnArchivo(String id, String fecha, String horaEntrada) {
        String archivoRegistro = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivoRegistro, true))) {
            writer.write(id + "," + fecha + "," + horaEntrada + "\n");
            System.out.println("Entrada registrada: " + id + " a las " + horaEntrada);
        } catch (IOException e) {
            System.out.println("Error al guardar la entrada en el archivo.");
        }
    }

    // Actualizar información de salida en la misma línea del archivo
    public static void actualizarSalidaArchivo(String id, String horaSalida) {
        File archivo = new File(ARCHIVO_REGISTRO);
        File archivoTemporal = new File("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt"); //NO ESTOY SEGURO SI AHI ES CORRECTO EL SUPUESTO ARCHIVO TEMPORAL

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo)); BufferedWriter writer = new BufferedWriter(new FileWriter(archivoTemporal))) {

            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith(id + ",")) {
                    // Actualizamos la línea con la hora de salida
                    linea = linea + "," + horaSalida;
                    System.out.println("Salida registrada: " + id + " a las " + horaSalida);
                }
                writer.write(linea + "\n");
            }

            // Reemplazar el archivo original por el temporal
            if (archivo.delete()) {
                archivoTemporal.renameTo(archivo);
            }

        } catch (IOException e) {
            System.out.println("Error al actualizar la salida en el archivo.");
        }
    }

    // Método para generar el código QR
    public static String Genera_QR(String id, String fecha, String hora) throws WriterException, IOException {
        String qrData = id + "|" + fecha + "|" + hora;
        int size = 250;

        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(qrData, BarcodeFormat.QR_CODE, size, size);

        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                image.setRGB(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        // Guardar la imagen como archivo
        String fileName = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\QRS" + id + ".png"; // Cambia esta ruta a donde quieras guardar
        File outputFile = new File(fileName);
        ImageIO.write(image, "png", outputFile);

        return fileName;
    }

    // Método para decodificar el contenido de una imagen QR
    public static String Leer_QR(String QRName) throws IOException, NotFoundException {
        File qrImage = new File(QRName);

        BufferedImage bufferedImage = ImageIO.read(qrImage);
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(
                new BufferedImageLuminanceSource(bufferedImage)));

        Result qrCodeResult = new MultiFormatReader().decode(bitmap);
        return qrCodeResult.getText();
    }

    // Borrar QR
    public static boolean borrarQR(String fileName) {
        File archivo = new File(fileName);
        if (archivo.exists()) {
            if (RegistroQR.help) {
                return true;
            } else {
                return archivo.delete();
            }
        }
        return false;
    }

    private static List<String> BuscarID(String producto, int PosicionIDs) {
        for (int i = 0; i < RegistroQR.IngresosSalidas.size(); i++) {
            String fila = RegistroQR.IngresosSalidas.get(i);
            String[] campos = fila.split(", ");

            if (campos[0].equals(producto) && campos[3].equals("*")) {
                PosicionID = i;
                return Arrays.asList(campos); //Retorna la lista encontrada
            }
        }
        //Retorno de la variable
        return null; //No se encontro el codigo
    }

}
