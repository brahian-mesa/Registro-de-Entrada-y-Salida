package com.mycompany.registroqr;

import java.io.*;
import java.util.*;

public class ArchivoPlano {

    public static final String ARCHIVO_ESTUDIANTES = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\EstudiantesDB.txt";
    public static final String ARCHIVO_DOCENTES = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\DocentesDB.txt";
    public static final String ARCHIVO_VISITANTES = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\VisitantesDB.txt";
    public static final String ARCHIVO_ADMINITRADORES = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\AdministrativosDB.txt";
    public static final String ARCHIVO_GRADUADOS = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\GraduadosDB.txt";
    public static final String ARCHIVO_USUARIOS = "";

    public static void guardarEstudiantes(String estudiantes) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_ESTUDIANTES, true))) {
            writer.println(estudiantes);
        } catch (IOException e) {
            System.out.println("Error al guardar el estudiante: " + e.getMessage());

        }
    }

    public static List<String> cargarEstdudiantes() {
        List<String> estudiantes = new ArrayList<>();
        File archivo = new File(ARCHIVO_ESTUDIANTES);

        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    estudiantes.add(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
        return estudiantes;

    }

    public static void guardarDocentes(String docentes) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_DOCENTES, true))) {
            writer.println(docentes);
        } catch (IOException e) {
            System.out.println("Error al guardar el docente: " + e.getMessage());

        }
    }

    public static List<String> cargarDocentes() {
        List<String> docentes = new ArrayList<>();
        File archivo = new File(ARCHIVO_DOCENTES);

        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    docentes.add(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
        return docentes;

    }

    public static void guardarVisitantes(String visitantes) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_VISITANTES, true))) {
            writer.println(visitantes);
        } catch (IOException e) {
            System.out.println("Error al guardar el visitante: " + e.getMessage());

        }
    }

    public static List<String> cargarVisitantes() {
        List<String> visitantes = new ArrayList<>();
        File archivo = new File(ARCHIVO_VISITANTES);

        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    visitantes.add(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
        return visitantes;

    }

    public static void guardarAdministradores(String administrativo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_ADMINITRADORES, true))) {
            writer.println(administrativo);
        } catch (IOException e) {
            System.out.println("Error al guardar a el adminitrador: " + e.getMessage());
        }
    }

    public static List<String> cargarAdminitradores() {
        List<String> Adminitrador = new ArrayList<>();
        File archivo = new File(ARCHIVO_ADMINITRADORES);

        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    Adminitrador.add(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
        return Adminitrador;
    }

    //GRADUADOS
    public static void guardarGraduados(String graduados) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_GRADUADOS, true))) {
            writer.println(graduados);
        } catch (IOException e) {
            System.out.println("Error al guardar al graduado: " + e.getMessage());
        }
    }

    public static List<String> cargarGraduados() {
        List<String> Graduado = new ArrayList<>();
        File archivo = new File(ARCHIVO_GRADUADOS);

        if (archivo.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    Graduado.add(linea);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }
        return Graduado;
    }

}
