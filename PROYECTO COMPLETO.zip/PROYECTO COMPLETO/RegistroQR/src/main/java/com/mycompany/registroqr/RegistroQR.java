package com.mycompany.registroqr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class RegistroQR {

    public static boolean help = true;

    //ARRAYLIST PARA ARCHIVOS PLANOS PARA CADA ROL (Se debe visualizar la informacion proporcionada en los formularios segun el rol)
    public static List<String> EstudiantesDB = new ArrayList<>();
    public static List<String> AdministrativosDB = new ArrayList<>();
    public static List<String> DocentesDB = new ArrayList<>();
    public static List<String> VisitantesDB = new ArrayList<>();
    public static List<String> GraduadosDB = new ArrayList<>();

    
    //ARRAYLIST PARA ARCHIVO PLANO DE INGRESOS Y SALIDAS (Numero identificacion, fecha entrada, fecha salida)
    public static List<String> IngresosSalidas = new ArrayList<>();

    //Nombre y Ruta del Archivo plano donde se guardan los datos de los Clientes. 
    public static final String IngresosSalidasDB = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt";

    public static void main(String[] args) {
        Ingreso_salida.CargarBD();
        RegistroQR.EstudiantesDB = ArchivoPlano.cargarEstdudiantes();
        RegistroQR.DocentesDB = ArchivoPlano.cargarDocentes();
        RegistroQR.VisitantesDB = ArchivoPlano.cargarVisitantes();
        RegistroQR.AdministrativosDB = ArchivoPlano.cargarAdminitradores();
        RegistroQR.GraduadosDB = ArchivoPlano.cargarGraduados();
        SwingUtilities.invokeLater(() -> new RegistroQR().createMobileUI());
    }

    private void createMobileUI() {
        // Crear el JFrame como una ventana de móvil
        JFrame formulario = new JFrame("Registro entrada y salida UCP");

        // Icono pequeño universidad (usando la segunda imagen como logo)
        formulario.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());

        formulario.setSize(400, 790); // Establecer el tamaño similar a una pantalla de móvil
        formulario.setLocationRelativeTo(null); // Centrar la ventana
        formulario.setResizable(false); // Evitar que el usuario cambie el tamaño de la ventana
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar la aplicación al cerrar la ventana

        // Cargar la imagen de fondo
        ImageIcon fondo = new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\rojo.jpg");

        // Panel para la imagen de fondo centrada con color de fondo verde
        JPanel fondoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // Establecer el color de fondo verde (RGB: 0, 128, 78)
                g.setColor(new Color(255, 213, 37));
                g.fillRect(0, 0, getWidth(), getHeight());

                // Obtener el tamaño de la imagen
                int imgWidth = fondo.getIconWidth();
                int imgHeight = fondo.getIconHeight();

                // Obtener el tamaño del panel (400x790)
                int panelWidth = getWidth();

                // Establecer la coordenada y para colocar la imagen en la parte superior
                int x = Math.max((panelWidth - imgWidth) / 2, 0);
                int y = 0; // Cambiar y a 0 para colocar la imagen en la parte superior

                // Dibujar la imagen en el tamaño original, en la parte superior
                g.drawImage(fondo.getImage(), x, y, imgWidth, imgHeight, this);
            }
        };
        fondoPanel.setLayout(null);
        fondoPanel.setBounds(0, 0, 400, 790);
 
        // Crear el JLabel para "Registro" y ajustarlo más arriba
        JLabel registroLabel = new JLabel("Registro", SwingConstants.CENTER);
        registroLabel.setFont(new Font("Playfair Display", Font.BOLD, 44));
        registroLabel.setForeground(Color.WHITE); // Texto blanco
        registroLabel.setBounds(100, 155, 200, 50); // Posicionar el JLabel centrado horizontalmente
        registroLabel.setBackground(new Color(216, 49, 53, 150));

        // Crear el JLabel para "acceso estudiante"
        JLabel accesoLabel = new JLabel("Acceso Usuario", SwingConstants.LEFT);
        accesoLabel.setFont(new Font("Playfair Display", Font.BOLD, 32));
        accesoLabel.setForeground(Color.WHITE); // Texto blanco
        accesoLabel.setBounds(80, 210, 360, 30); // Posicionarlo justo debajo a la izquierda
        accesoLabel.setBackground(new Color(216, 49, 53, 150));

        // Crear el JTextArea para el texto largo (autorización)
        JTextArea textoAutorizacion = new JTextArea();
        JPanel panelTextoAutorizacion = new JPanel();
        panelTextoAutorizacion.setLayout(new BorderLayout());
        textoAutorizacion.setText("Al aceptar el envío del presente formulario, "
                + "expresamente autorizo de manera voluntaria, previa, informada e inequívoca "
                + "a la Universidad Católica de Pereira, para el tratamiento de los datos personales "
                + "recolectados por cualquiera medio, ya sea virtual, personal, telefónico y otros "
                + "referentes a mi información personal, la cual declaro la he suministrado de forma "
                + "voluntaria y es completa, confiable, exacta y verídica; de acuerdo a la ley 1581 de 2021 "
                + "por la cual se dictan disposiciones generales para la protección de datos personales.");
        textoAutorizacion.setLineWrap(true);
        textoAutorizacion.setWrapStyleWord(true);
        textoAutorizacion.setEditable(false);
        textoAutorizacion.setFont(new Font("Roboto", Font.PLAIN, 16));
        textoAutorizacion.setBounds(15, 260, 350, 250);
        textoAutorizacion.setBackground(new Color(216, 49, 53, 150));
        textoAutorizacion.setForeground(Color.WHITE);
        textoAutorizacion.setOpaque(false);
        textoAutorizacion.setFocusable(false);

        // Crear los JRadioButton para "Sí" y "No"
        JRadioButton siButton = new JRadioButton("Sí");
        siButton.setBounds(150, 520, 50, 30);
        siButton.setFont(new Font("Roboto", Font.PLAIN, 18));
        siButton.setOpaque(false);
        siButton.setContentAreaFilled(false);
        siButton.setForeground(Color.WHITE);

        JRadioButton noButton = new JRadioButton("No");
        noButton.setBounds(200, 520, 50, 30);
        noButton.setFont(new Font("Roboto", Font.PLAIN, 18));
        noButton.setOpaque(false);
        noButton.setContentAreaFilled(false);
        noButton.setForeground(Color.WHITE);

        // Agrupar los botones de opción
        ButtonGroup group = new ButtonGroup();
        group.add(siButton);
        group.add(noButton);

        // Crear un JLabel para la pregunta "¿Qué rol tiene en la universidad?"
        JLabel rolLabel = new JLabel("¿Qué Rol tiene en la universidad?", SwingConstants.LEFT);
        rolLabel.setFont(new Font("Roboto", Font.BOLD, 18));
        rolLabel.setForeground(Color.WHITE);
        rolLabel.setBounds(60, 560, 360, 30);

        String[] roles = {"Estudiante", "Administrativo", "Docente", "Visitante", "Graduado", "Administrador"};
        JComboBox<String> rolComboBox = new JComboBox<>(roles);
        rolComboBox.setBounds(95, 600, 200, 30);
        rolComboBox.setFont(new Font("Roboto", Font.BOLD, 14));

        // Crear el campo de contraseña pero inicialmente oculto
        JLabel passwordLabel = new JLabel("Contraseña");
        passwordLabel.setFont(new Font("Roboto", Font.BOLD, 18));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(140, 625, 360, 30);
        passwordLabel.setVisible(false);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(95, 655, 200, 25);
        passwordField.setFont(new Font("Franklin Gothic Book", Font.BOLD, 14));
        passwordField.setVisible(false);

// Añadir el campo de contraseña al panel
        fondoPanel.add(passwordLabel);
        fondoPanel.add(passwordField);

// Listener para mostrar/ocultar el campo de contraseña según el rol seleccionado
rolComboBox.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String rolSeleccionado = (String) rolComboBox.getSelectedItem();
        if ("Administrador".equals(rolSeleccionado)) {
            passwordLabel.setVisible(true);
            passwordField.setText("");
            passwordField.setVisible(true);

            // Deshabilitar los botones "Sí" y "No"
            siButton.setEnabled(false);
            noButton.setEnabled(false);
        } else {
            passwordField.setText("");
            passwordLabel.setVisible(false);
            passwordField.setVisible(false);

            // Habilitar los botones "Sí" y "No"
            siButton.setEnabled(true);
            noButton.setEnabled(true);
        }
    }
});


        // Crear el botón "Ingresar"
        //----> Boton Ingresar <----
        JButton botonIngresar = new JButton("Ingresar");
        botonIngresar.setBounds(0, 693, 400, 60);
        botonIngresar.setFont(new Font("Playfair Display", Font.BOLD, 20));
        botonIngresar.setBackground(new Color(0, 128, 78));
        botonIngresar.setForeground(Color.WHITE);
        botonIngresar.setFocusPainted(false);

  // Acción del botón "Ingresar"
botonIngresar.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String rolSeleccionado = (String) rolComboBox.getSelectedItem();

        if ("Administrador".equals(rolSeleccionado)) {
            // Validar contraseña solo si es administrador
            String contrasena = new String(passwordField.getPassword());
            if ("papa2000".equals(contrasena)) {
                new Admin(); // Abrir la interfaz de administrador
                passwordField.setText("");
            } else {
                JOptionPane.showMessageDialog(formulario, "Contraseña incorrecta. Acceso denegado.", "Error", JOptionPane.ERROR_MESSAGE);
                passwordField.setText("");
            }
        } else if (siButton.isSelected()) {
            // Continuar con el proceso normal para los otros roles
            switch (rolSeleccionado) {
                case "Estudiante":
                    new RegistroEstudiantes();
                    break;
                case "Administrativo":
                    new RegistroAdministradores();
                    break;
                case "Visitante":
                    new RegistroVisitantes();
                    break;
                case "Docente":
                    new RegistroDocente();
                    break;
                case "Graduado":
                    new RegistroGraduado();
                    break;
                default:
                    JOptionPane.showMessageDialog(formulario, "Bienvenido, " + rolSeleccionado + ".");
                    break;
            }
        } else {
            JOptionPane.showMessageDialog(null, "No puede continuar, seleccione la opción 'Sí' para seguir", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }
    }
});


        // Añadir los componentes al panel de fondo
        fondoPanel.add(registroLabel);
        fondoPanel.add(accesoLabel); 
        fondoPanel.add(textoAutorizacion);
        fondoPanel.add(siButton);
        fondoPanel.add(noButton);
        fondoPanel.add(rolLabel);
        fondoPanel.add(rolComboBox);
        fondoPanel.add(botonIngresar); // Añadir el botón "Ingresar"

        // Añadir el panel al JFrame
        formulario.setContentPane(fondoPanel);

        // Hacer visible la ventana
        formulario.setVisible(true);
    }

}