package com.mycompany.registroqr;

import com.itextpdf.text.DocumentException;
import javax.swing.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import com.toedter.calendar.JDateChooser;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.table.DefaultTableModel;

public class Admin {

    public Admin() {
        // Ventana principal del administrador
        JFrame interfazAdmin = new JFrame("Bienvenido Administrador");
        JOptionPane.showMessageDialog(interfazAdmin, "Bienvenido Administrador", "Acceso autorizado", JOptionPane.INFORMATION_MESSAGE);
        interfazAdmin.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\Azul.jpg").getImage());
        interfazAdmin.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
        interfazAdmin.setSize(400, 400);
        interfazAdmin.setLocationRelativeTo(null); //posicion del JFrame
        interfazAdmin.setResizable(false); //anula la modificacion dell tamaño de la ventana
        interfazAdmin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //Todo el programa se cierra
        
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen de fondo
                Image imagen = new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\Azul.jpg").getImage();
                // Dibujar la imagen escalada para cubrir todo el panel
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelFondo.setLayout(null);

        // Botón "Informes por Tipo de Usuario"
        JButton botonInformesTipoUsuario = new JButton("Informes por Tipo de Usuario");
        botonInformesTipoUsuario.setBounds(50, 50, 300, 50);
        botonInformesTipoUsuario.addActionListener(e -> abrirVentanaInformesTipoUsuario());
        panelFondo.add(botonInformesTipoUsuario);

        // Botón "Días con más Visitas"
        JButton botonDiasConMasVisitas = new JButton("Días con más Visitas");
        botonDiasConMasVisitas.setBounds(50, 120, 300, 50);
        botonDiasConMasVisitas.addActionListener(e -> abrirVentanaDiasConMasVisitas());
        panelFondo.add(botonDiasConMasVisitas);

        // Botón "Horas Más Activas"
        JButton botonHorasMasActivas = new JButton("Horas Más Activas");
        botonHorasMasActivas.setBounds(50, 190, 300, 50);
        botonHorasMasActivas.addActionListener(e -> abrirVentanaHorasMasActivas());
        panelFondo.add(botonHorasMasActivas);
        
        interfazAdmin.add(panelFondo);
        interfazAdmin.setVisible(true);
    }

    // -------------------------- TIPO USUARIO PRIMER BOTON --------------------------------------- \\ BRAHIAN
    private void abrirVentanaInformesTipoUsuario() {
        JFrame ventanaInformes = new JFrame("Informes por Tipo de Usuario");
        ventanaInformes.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
        ventanaInformes.setSize(400, 400);
        ventanaInformes.setLocationRelativeTo(null);
        ventanaInformes.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventanaInformes.setLayout(null);

        // Crear un JPanel personalizado para que actúe como fondo
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen de fondo
                Image imagen = new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\Azul.jpg").getImage();
                // Dibujar la imagen escalada para cubrir todo el panel
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelFondo.setLayout(null); // Establecemos un layout nulo para posicionar componentes

        // Añadir componentes al panel con fondo
        JLabel labelRol = new JLabel("Seleccione el Rol:");
        labelRol.setBounds(150, 30, 120, 25);
        labelRol.setForeground(Color.WHITE); // Cambiar el color del texto a blanco
        panelFondo.add(labelRol);

        JComboBox<String> comboBoxRol = new JComboBox<>(new String[]{"Estudiante", "Administrativo", "Docente", "Visitante", "Graduado"});
        comboBoxRol.setBounds(100, 60, 200, 25);
        panelFondo.add(comboBoxRol);

        JLabel labelOrden = new JLabel("Ordenar por:");
        labelOrden.setBounds(160, 90, 120, 25);
        labelOrden.setForeground(Color.WHITE); // Cambiar el color del texto a blanco
        panelFondo.add(labelOrden);

        JComboBox<String> comboBoxOrden = new JComboBox<>(new String[]{"Cédula", "Nombre", "Área"});
        comboBoxOrden.setBounds(100, 120, 200, 25);
        panelFondo.add(comboBoxOrden);

        JLabel labelSalida = new JLabel("Tipo de Salida:");
        labelSalida.setBounds(160, 150, 120, 25);
        labelSalida.setForeground(Color.WHITE); // Cambiar el color del texto a blanco
        panelFondo.add(labelSalida);

        JComboBox<String> comboBoxSalida = new JComboBox<>(new String[]{"Pantalla", "Excel", "PDF"});
        comboBoxSalida.setBounds(100, 180, 200, 25);
        panelFondo.add(comboBoxSalida);

        JButton botonGenerarInforme = new JButton("Generar Informe");
        botonGenerarInforme.setBounds(100, 300, 200, 30);
        botonGenerarInforme.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rolSeleccionado = (String) comboBoxRol.getSelectedItem();
                String tipoSalida = (String) comboBoxSalida.getSelectedItem();
                String criterioOrden = (String) comboBoxOrden.getSelectedItem();
                generarInforme(rolSeleccionado, tipoSalida, criterioOrden);
            }
        });
        panelFondo.add(botonGenerarInforme);

        // Añadir el panel de fondo a la ventana
        ventanaInformes.setContentPane(panelFondo);
        ventanaInformes.setVisible(true);
    }

    private void generarInforme(String rol, String tipoSalida, String criterioOrden) {
        // Validar que se haya seleccionado un rol
        if (rol == null || rol.isEmpty()) {
            JOptionPane.showMessageDialog(null, 
                "Por favor seleccione un rol para generar el informe", 
                "Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<String> datosRol = obtenerDatosPorRol(rol);
        
        // Validar que existan datos para el rol seleccionado
        if (datosRol == null || datosRol.isEmpty()) {
            JOptionPane.showMessageDialog(null, 
                "No hay datos disponibles para el rol seleccionado: " + rol, 
                "Sin datos", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Ordenar los datos según el criterio seleccionado
        if (criterioOrden != null) {
            switch (criterioOrden) {
                case "Cédula":
                    // Ordenar de menor a mayor por cédula
                    datosRol.sort((a, b) -> {
                        String cedulaA = a.split(",")[1].trim();
                        String cedulaB = b.split(",")[1].trim();

                        // Solo convertir si ambas cédulas son numéricas
                        if (esNumerico(cedulaA) && esNumerico(cedulaB)) {
                            return Long.compare(Long.parseLong(cedulaA), Long.parseLong(cedulaB));
                        }
                        return cedulaA.compareTo(cedulaB); // Si no es numérico, ordena como texto
                    });
                    break;

                case "Nombre":
                    datosRol.sort((a, b) -> {
                        String nombreA = a.split(",")[2].trim();
                        String nombreB = b.split(",")[2].trim();
                        return nombreA.compareTo(nombreB);
                    });
                    break;

                case "Área":
                    datosRol.sort((a, b) -> {
                        String areaA = a.split(",")[3].trim();
                        String areaB = b.split(",")[3].trim();
                        return areaA.compareTo(areaB); // Si no es numérico, ordena como texto
                    });
                    break;
            }
        }

        // Crear el informe
        StringBuilder informe = new StringBuilder("Informe de " + rol + "s:\n\n");
        for (String dato : datosRol) {
            informe.append(dato).append("\n");
        }

        // Generar salida según el tipo seleccionado
        switch (tipoSalida) {
            case "Pantalla":
                // Crear ventana para la tabla
                JFrame frameTabla = new JFrame("Informe de " + rol);
                frameTabla.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
                frameTabla.setSize(800, 600);
                frameTabla.setLocationRelativeTo(null);
                frameTabla.setLayout(new BorderLayout());

                // Crear modelo de tabla
                DefaultTableModel modelo = new DefaultTableModel();
                
                // Definir columnas según el rol
                if (rol.equals("Visitante")) {
                    modelo.addColumn("Tipo ID");
                    modelo.addColumn("Número ID");
                    modelo.addColumn("Nombre");
                    modelo.addColumn("Área");
                    modelo.addColumn("Motivo");
                    modelo.addColumn("Fecha");
                    modelo.addColumn("Hora");
                } else {
                    modelo.addColumn("Tipo ID");
                    modelo.addColumn("Número ID");
                    modelo.addColumn("Nombre");
                    modelo.addColumn("Área/Programa");
                }

                // Agregar datos a la tabla
                for (String dato : datosRol) {
                    String[] partes = dato.split(",");
                    modelo.addRow(partes);
                }

                // Crear tabla y configurar
                JTable tabla = new JTable(modelo);
                tabla.setFont(new Font("Arial", Font.PLAIN, 14));
                tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
                tabla.setRowHeight(25);
                tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                // Agregar tabla al frame con scroll
                JScrollPane scrollPane = new JScrollPane(tabla);
                frameTabla.add(scrollPane, BorderLayout.CENTER);

                // Agregar título
                JLabel titulo = new JLabel("Informe de " + rol + "s", SwingConstants.CENTER);
                titulo.setFont(new Font("Arial", Font.BOLD, 16));
                titulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
                frameTabla.add(titulo, BorderLayout.NORTH);

                frameTabla.setVisible(true);
                break;
            case "Excel":
                if (datosRol != null && !datosRol.isEmpty()) {
                    ExportarArchivos.exportarAExcel("Informe " + rol, datosRol, rol);  // Pasar el tipo de rol aquí
                } else {
                    JOptionPane.showMessageDialog(null, "No hay datos disponibles para exportar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                break;
            case "PDF":
                if (datosRol != null && !datosRol.isEmpty()) {
                    try {
                        ExportarArchivos.exportarPDFTipoDeUsuarios(datosRol, "Informe " + rol, rol);
                    } catch (DocumentException e) {
                        System.err.println("Error al exportar a PDF: " + e.getMessage());
                    }
                } else {
                    System.err.println("No hay datos disponibles para el rol: " + rol);
                }
                break;
        }
    }

// Método auxiliar para verificar si una cadena es numérica
    private boolean esNumerico(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private List<String> obtenerDatosPorRol(String rol) {
        switch (rol) {
            case "Estudiante":
                return RegistroQR.EstudiantesDB;
            case "Administrativo":
                return RegistroQR.AdministrativosDB;
            case "Docente":
                return RegistroQR.DocentesDB;
            case "Visitante":
                return RegistroQR.VisitantesDB;
            case "Graduado":
                return RegistroQR.GraduadosDB;
            default:
                return null;
        }
    }

    // -------------------------- MAS VISITANTES SEGUNDO BOTON --------------------------------------- \\ JHOANentonce
private void abrirVentanaDiasConMasVisitas() {

    JPanel panelFondo = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Cargar la imagen de fondo
            Image imagen = new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\Azul.jpg").getImage();
            // Dibujar la imagen escalada para cubrir todo el panel
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    };
    panelFondo.setLayout(null); // Establecemos un layout nulo para posicionar componentes
    JFrame ventanaDias = new JFrame("Días con más Visitas");
    ventanaDias.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
    ventanaDias.setSize(400, 400);
    ventanaDias.setLocationRelativeTo(null);
    ventanaDias.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    JLabel labelFechaI = new JLabel("Fecha inicial");
    labelFechaI.setBounds(30, 40, 200, 25);
    labelFechaI.setForeground(Color.WHITE);
    panelFondo.add(labelFechaI);

    JDateChooser dateChooser = new JDateChooser();
    dateChooser.setBounds(160, 40, 190, 25);
    dateChooser.setForeground(Color.WHITE);
    panelFondo.add(dateChooser);

    JLabel labelFechaF = new JLabel("Fecha Final");
    labelFechaF.setBounds(30, 100, 200, 25);
    labelFechaF.setForeground(Color.WHITE);
    panelFondo.add(labelFechaF);

    JDateChooser dateChooser2 = new JDateChooser();
    dateChooser2.setBounds(160, 100, 190, 25);
    dateChooser2.setForeground(Color.WHITE);
    panelFondo.add(dateChooser2);

    JLabel labelSalida = new JLabel("Tipo de Salida:");
    labelSalida.setBounds(30, 160, 120, 25);
    labelSalida.setForeground(Color.WHITE);
    panelFondo.add(labelSalida);

    JComboBox<String> comboBoxSalida = new JComboBox<>(new String[]{"Pantalla", "Excel", "PDF"});
    comboBoxSalida.setBounds(160, 160, 200, 25);
    comboBoxSalida.setForeground(Color.BLACK);
    panelFondo.add(comboBoxSalida);

    JButton botonGenerarInforme = new JButton("Generar Informe");
    botonGenerarInforme.setBounds(100, 220, 200, 30);
    panelFondo.add(botonGenerarInforme);
    botonGenerarInforme.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            Date fechaInicial = dateChooser.getDate();
            Date fechaFinal = dateChooser2.getDate();
            String tipoSalida = (String) comboBoxSalida.getSelectedItem();
            generarInformeDias(fechaInicial, fechaFinal, tipoSalida);
        }
    });

    ventanaDias.add(panelFondo);
    ventanaDias.setVisible(true);
}

private void generarInformeDias(Date fechaInicial, Date fechaFinal, String tipoSalida) {
    // Validar que ambas fechas hayan sido seleccionadas
    if (fechaInicial == null || fechaFinal == null) {
        JOptionPane.showMessageDialog(null, 
            "Por favor seleccione ambas fechas para generar el informe", 
            "Error", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Validar que la fecha inicial no sea posterior a la fecha final
    if (fechaInicial.after(fechaFinal)) {
        JOptionPane.showMessageDialog(null, 
            "La fecha inicial no puede ser posterior a la fecha final", 
            "Error", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir las fechas a un formato que pueda ser utilizado para comparación
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String fechaInicialStr = sdf.format(fechaInicial);
    String fechaFinalStr = sdf.format(fechaFinal);

        // Contar registros en el archivo plano
        List<String> registros = new ArrayList<>(); // Lista temporal para almacenar los registros
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\VisitantesDB.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(","); // Asumiendo que las partes están separadas por comas
                if (partes.length < 7) { // Verificar que hay suficientes partes
                    continue; // Si no hay suficientes partes, saltar esta línea
                }
                String fechaRegistroStr = partes[5]; // Asumiendo que la fecha está en la sexta posición
                Date fechaRegistro = sdf.parse(fechaRegistroStr);

                // Verificar si la fecha está dentro del rango
                if ((fechaRegistro.equals(fechaInicial) || !fechaRegistro.before(fechaInicial))
                        && (fechaRegistro.equals(fechaFinal) || !fechaRegistro.after(fechaFinal))) {
                    registros.add(linea); // Agregar el registro a la lista
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo: " + ex.getMessage());
            return;
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar las fechas: " + ex.getMessage());
            return;
        }

        // Mostrar la cantidad de registros encontrados
        int contadorRegistros = registros.size();
        StringBuilder informe = new StringBuilder("Cantidad de registros entre " + fechaInicialStr + " y " + fechaFinalStr + ": " + contadorRegistros + "\n\n");

        // Crear un mapa para contar la cantidad de registros por fecha
        Map<String, Integer> registrosPorFecha = new HashMap<>();

        // Contar cuántos registros hay para cada fecha
        for (String registro : registros) {
            String[] partes = registro.split(", ");
            String fecha = partes[5]; // Fecha en el índice 5
            registrosPorFecha.put(fecha, registrosPorFecha.getOrDefault(fecha, 0) + 1);
        }

        // Agregar los resultados al informe
        for (Map.Entry<String, Integer> entry : registrosPorFecha.entrySet()) {
            String fecha = entry.getKey();
            int cantidad = entry.getValue();
            informe.append("Fecha: ").append(fecha).append("\n");
            informe.append("Personas inscritas: ").append(cantidad).append("\n\n");
        }

        // Salidas según el tipo de salida
        switch (tipoSalida) {
            case "Pantalla":
                // Crear ventana para la tabla
                JFrame frameTablaVisitas = new JFrame("Informe de Visitas");
                frameTablaVisitas.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
                frameTablaVisitas.setSize(800, 600);
                frameTablaVisitas.setLocationRelativeTo(null);
                frameTablaVisitas.setLayout(new BorderLayout());

                // Crear modelo de tabla
                DefaultTableModel modeloVisitas = new DefaultTableModel();
                modeloVisitas.addColumn("Fecha");
                modeloVisitas.addColumn("Cantidad de Visitas");

                // Ordenar el mapa por fecha
                TreeMap<String, Integer> registrosOrdenados = new TreeMap<>(registrosPorFecha);

                // Agregar datos a la tabla
                for (Map.Entry<String, Integer> entry : registrosOrdenados.entrySet()) {
                    modeloVisitas.addRow(new Object[]{
                        entry.getKey(),
                        entry.getValue()
                    });
                }

                // Crear tabla y configurar
                JTable tablaVisitas = new JTable(modeloVisitas);
                tablaVisitas.setFont(new Font("Arial", Font.PLAIN, 14));
                tablaVisitas.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
                tablaVisitas.setRowHeight(25);
                tablaVisitas.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                // Agregar tabla al frame con scroll
                JScrollPane scrollPaneVisitas = new JScrollPane(tablaVisitas);
                frameTablaVisitas.add(scrollPaneVisitas, BorderLayout.CENTER);

                // Agregar título y total
                JPanel panelSuperior = new JPanel(new BorderLayout());
                JLabel tituloVisitas = new JLabel("Informe de Visitas por Día", SwingConstants.CENTER);
                tituloVisitas.setFont(new Font("Arial", Font.BOLD, 16));
                tituloVisitas.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
                
                JLabel totalVisitas = new JLabel("Total de registros: " + contadorRegistros, SwingConstants.CENTER);
                totalVisitas.setFont(new Font("Arial", Font.PLAIN, 14));
                totalVisitas.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
                
                panelSuperior.add(tituloVisitas, BorderLayout.NORTH);
                panelSuperior.add(totalVisitas, BorderLayout.CENTER);
                frameTablaVisitas.add(panelSuperior, BorderLayout.NORTH);

                frameTablaVisitas.setVisible(true);
                break;
            case "PDF":
                try {
                    ExportarArchivos.exportarPDFVisitantes(registros, fechaInicialStr, fechaFinalStr);
                } catch (DocumentException ex) {
                    JOptionPane.showMessageDialog(null, "Error al generar el PDF: " + ex.getMessage());
                }
                break;
            case "Excel":
                // Aquí puedes agregar la lógica para exportar a Excel
                try {
                    ExportarArchivos.exportarExcelSoloCantidadYFecha(registros, fechaInicialStr, fechaFinalStr);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error al generar el archivo Excel: " + ex.getMessage());
                }
                break;
        }
    }

//ACABA SEGUNDO BOTON
// -------------------------- HORA MAS ACTIVA TERCER BOTON --------------------------------------- \\ CARLOS Y SEBASTIAN
    private void abrirVentanaHorasMasActivas() {

        JFrame ventanaHoras = new JFrame("Horas Más Activas");
        ventanaHoras.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
        ventanaHoras.setSize(400, 400);
        ventanaHoras.setLocationRelativeTo(null);
        ventanaHoras.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Crear un JPanel personalizado para que actúe como fondo
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen de fondo
                Image imagen = new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\Azul.jpg").getImage();
                // Dibujar la imagen escalada para cubrir todo el panel
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelFondo.setLayout(null);

        JLabel labelFechaInicial = new JLabel("Seleccione la fecha inicial:");
        labelFechaInicial.setBounds(17, 50, 200, 25);
        labelFechaInicial.setForeground(Color.WHITE);
        panelFondo.add(labelFechaInicial);

        JDateChooser dateChooserInicial = new JDateChooser();
        dateChooserInicial.setBounds(170, 50, 200, 25);
        panelFondo.add(dateChooserInicial);

        JLabel labelFechaFinal = new JLabel("Seleccione la fecha final:");
        labelFechaFinal.setBounds(20, 100, 200, 25);
        labelFechaFinal.setForeground(Color.WHITE);
        panelFondo.add(labelFechaFinal);

        JDateChooser dateChooserFinal = new JDateChooser();
        dateChooserFinal.setBounds(170, 100, 200, 25);
        panelFondo.add(dateChooserFinal);

        JButton buttonPantalla = new JButton("Pantalla");
        buttonPantalla.setBounds(100, 180, 200, 25);
        buttonPantalla.setBackground(new Color(242, 244, 247));
        buttonPantalla.setForeground(Color.BLACK);
        buttonPantalla.addActionListener(e -> {
            Date fechaInicial = dateChooserInicial.getDate();
            Date fechaFinal = dateChooserFinal.getDate();
            if (fechaInicial != null && fechaFinal != null) {
                mostrarInformeRango(fechaInicial, fechaFinal);
            } else {
                JOptionPane.showMessageDialog(ventanaHoras, "Por favor seleccione ambas fechas.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });
        panelFondo.add(buttonPantalla);

// Crear el botón para exportar a Excel
        JButton buttonExcel = new JButton("Excel");
        buttonExcel.setBounds(100, 230, 200, 25);
        buttonExcel.setBackground(new Color(242, 244, 247));
        buttonExcel.setForeground(Color.BLACK);
        buttonExcel.addActionListener(e -> {
            Date fechaInicial = dateChooserInicial.getDate();
            Date fechaFinal = dateChooserFinal.getDate();

            if (fechaInicial != null && fechaFinal != null) {
                try {
                    // Crear instancia de ExportarArchivos
                    ExportarArchivos exportarArchivos = new ExportarArchivos();
                    // Llamar al método de exportación
                    exportarArchivos.exportarAExcelConEncabezados(fechaInicial, fechaFinal);
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(ventanaHoras,
                            "Error al exportar el archivo a Excel: " + ex.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(ventanaHoras,
                        "Por favor, seleccione ambas fechas para exportar.",
                        "Advertencia",
                        JOptionPane.WARNING_MESSAGE);
            }
        });

        panelFondo.add(buttonExcel);

        // Botón para exportar a PDF
        JButton buttonPdf = new JButton("PDF");
        buttonPdf.setBounds(100, 280, 200, 25);
        buttonPdf.setBackground(new Color(242, 244, 247));
        buttonPdf.setForeground(Color.BLACK);
        buttonPdf.addActionListener(e -> {
            Date fechaInicial = dateChooserInicial.getDate();
            Date fechaFinal = dateChooserFinal.getDate();

            if (fechaInicial == null || fechaFinal == null) {
                JOptionPane.showMessageDialog(ventanaHoras, 
                    "Por favor seleccione ambas fechas para generar el PDF", 
                    "Error", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (fechaInicial.after(fechaFinal)) {
                JOptionPane.showMessageDialog(ventanaHoras, 
                    "La fecha inicial no puede ser posterior a la fecha final", 
                    "Error", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                // Llamar al método exportarAPDF con las fechas seleccionadas
                ExportarArchivos.exportarAPDFHoras(fechaInicial, fechaFinal);
                JOptionPane.showMessageDialog(ventanaHoras,
                    "PDF generado exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (DocumentException ex) {
                JOptionPane.showMessageDialog(ventanaHoras, 
                    "Error al exportar a PDF: " + ex.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        panelFondo.add(buttonPdf);

        ventanaHoras.add(panelFondo);
        ventanaHoras.setVisible(true);
    }

    private void mostrarInformeRango(Date fechaInicial, Date fechaFinal) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        String fechaInicio = formatoFecha.format(fechaInicial);
        String fechaFin = formatoFecha.format(fechaFinal);

        Map<String, Map<String, Integer>> informePorFecha = new TreeMap<>();
        Map<String, Integer> totalPorFecha = new TreeMap<>();
        Map<String, Integer> totalPorHora = new TreeMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                String fechaRegistro = partes[1];
                String horaIngreso = partes[2];

                if (fechaRegistro.compareTo(fechaInicio) >= 0 && fechaRegistro.compareTo(fechaFin) <= 0) {
                    Map<String, Integer> conteoPorHora = informePorFecha.getOrDefault(fechaRegistro, new TreeMap<>());
                    conteoPorHora.merge(horaIngreso, 1, Integer::sum);
                    informePorFecha.put(fechaRegistro, conteoPorHora);
                    totalPorFecha.merge(fechaRegistro, 1, Integer::sum);
                    totalPorHora.merge(horaIngreso, 1, Integer::sum);
                }
            }

            // Crear ventana para la tabla
            JFrame frameTabla = new JFrame("Informe de Ingresos");
            frameTabla.setIconImage(new ImageIcon("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\IconoUCP.jpg").getImage());
            frameTabla.setSize(800, 600);
            frameTabla.setLocationRelativeTo(null);
            frameTabla.setLayout(new BorderLayout());

            // Crear modelo de tabla y panel principal
            DefaultTableModel modelo;
            JPanel panelPrincipal = new JPanel(new BorderLayout());
            JTable tabla;

            if (fechaInicio.equals(fechaFin)) {
                // Modelo para un solo día
                modelo = new DefaultTableModel(
                        new String[]{"Hora", "Cantidad de Ingresos"}, 0
                );

                Map<String, Integer> horasDelDia = informePorFecha.get(fechaInicio);
                if (horasDelDia != null) {
                    for (Map.Entry<String, Integer> entry : horasDelDia.entrySet()) {
                        modelo.addRow(new Object[]{entry.getKey(), entry.getValue()});
                    }
                }

                // Agregar título para un día
                JLabel titulo = new JLabel("Ingresos del día " + fechaInicio
                        + " - Total: " + totalPorFecha.getOrDefault(fechaInicio, 0),
                        SwingConstants.CENTER);
                titulo.setFont(new Font("Arial", Font.BOLD, 16));
                panelPrincipal.add(titulo, BorderLayout.NORTH);

            } else {
                // Modelo para múltiples días
                modelo = new DefaultTableModel(
                        new String[]{"Fecha", "Total Ingresos", "Hora más activa", "Ingresos en hora pico"}, 0
                );

                for (Map.Entry<String, Map<String, Integer>> entry : informePorFecha.entrySet()) {
                    String fecha = entry.getKey();
                    int totalDia = totalPorFecha.get(fecha);
                    Map.Entry<String, Integer> horaMasActiva = entry.getValue().entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .orElse(null);

                    if (horaMasActiva != null) {
                        modelo.addRow(new Object[]{
                            fecha,
                            totalDia,
                            horaMasActiva.getKey(),
                            horaMasActiva.getValue()
                        });
                    }
                }
            }

            // Crear tabla y configurar
            tabla = new JTable(modelo);
            tabla.setFont(new Font("Arial", Font.PLAIN, 14));
            tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
            tabla.setRowHeight(25);
            tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

            // Agregar tabla al panel con scroll
            JScrollPane scrollPane = new JScrollPane(tabla);
            panelPrincipal.add(scrollPane, BorderLayout.CENTER);

            // Panel para el Top 3 y Promedio
            JPanel panelInferior = new JPanel(new GridLayout(1, 2, 10, 0));
            panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Panel para el Top 3 (izquierda)
            JPanel panelTop3 = new JPanel();
            panelTop3.setLayout(new BoxLayout(panelTop3, BoxLayout.Y_AXIS));
            panelTop3.setBorder(BorderFactory.createTitledBorder("Top 3"));

            JTextArea areaTop3 = new JTextArea(5, 30);
            areaTop3.setEditable(false);
            areaTop3.setFont(new Font("Arial", Font.PLAIN, 14));

            // Agregar Top 3
            StringBuilder top3Text = new StringBuilder();
            if (fechaInicio.equals(fechaFin)) {
                top3Text.append("TOP 3 HORAS MÁS ACTIVAS:\n");
                totalPorHora.entrySet().stream()
                        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                        .limit(3)
                        .forEach(entry -> top3Text.append(String.format("%s - %d ingresos\n",
                        entry.getKey(), entry.getValue())));
            } else {
                top3Text.append("TOP 3 FECHAS MÁS ACTIVAS:\n");
                totalPorFecha.entrySet().stream()
                        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                        .limit(3)
                        .forEach(entry -> top3Text.append(String.format("%s - %d ingresos\n",
                        entry.getKey(), entry.getValue())));
            }
            areaTop3.setText(top3Text.toString());
            panelTop3.add(new JScrollPane(areaTop3));

            // Panel para el Promedio (derecha)
            JPanel panelPromedio = new JPanel();
            panelPromedio.setLayout(new BoxLayout(panelPromedio, BoxLayout.Y_AXIS));
            panelPromedio.setBorder(BorderFactory.createTitledBorder("Estadísticas"));

            JTextArea areaPromedio = new JTextArea(5, 30);
            areaPromedio.setEditable(false);
            areaPromedio.setFont(new Font("Arial", Font.PLAIN, 14));

            // Calcular y mostrar el promedio
            if (!fechaInicio.equals(fechaFin)) {
                int totalVisitantes = totalPorFecha.values().stream().mapToInt(Integer::intValue).sum();
                double promedio = totalVisitantes / (double) totalPorFecha.size();

                StringBuilder statsText = new StringBuilder();
                statsText.append("ESTADÍSTICAS DEL PERÍODO:\n\n");
                statsText.append(String.format("Total días: %d\n", totalPorFecha.size()));
                statsText.append(String.format("Total Ingresos: %d\n", totalVisitantes));
                statsText.append(String.format("Promedio diario: %.2f Ingresos", promedio));

                areaPromedio.setText(statsText.toString());
                panelPromedio.add(new JScrollPane(areaPromedio));
            }

            // Agregar paneles al panel inferior
            panelInferior.add(panelTop3);
            panelInferior.add(panelPromedio);

            // Agregar todo al frame
            panelPrincipal.add(panelInferior, BorderLayout.SOUTH);
            frameTabla.add(panelPrincipal);
            frameTabla.setVisible(true);

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de registros", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

// Métodos para exportar a Excel y PDF

}
