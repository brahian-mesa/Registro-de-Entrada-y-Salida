package com.mycompany.registroqr;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExportarArchivos {

    public static String guardarArchivoComo(String Titulo, String TiposArchivos, String Exten1, String Exten2) {
        // Obtener la ruta del escritorio del usuario
        String rutaEscritorio = System.getProperty("user.home"); //Ver documentacion arriba

        //y le agregamos al final el nombre del escritorio 
        rutaEscritorio = rutaEscritorio.replace("C:", "D:") + "C:\\Users\\usuario\\OneDrive\\Desktop";
               
        
        // Crear el JFileChooser con la ruta predeterminada en el escritorio
        JFileChooser fileChooser = new JFileChooser(new File(rutaEscritorio));

        //Establecer el titulo del grabar como
        fileChooser.setDialogTitle(Titulo);

        //Establecer la ruta predeterminada para guardar el archivo
        fileChooser.setCurrentDirectory(new File(rutaEscritorio));

        // Establecer el nombre de archivo predeterminado (opcional)
        fileChooser.setSelectedFile(new File("NombreArchivo." + Exten2));

        // Añadir un filtro para los archivos Excel (.xls y .xlsx)
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(TiposArchivos, Exten1, Exten2));

        // Mostrar el cuadro de diálogo de guardar
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fileChooser.getSelectedFile();
            String rutaArchivo = archivoSeleccionado.getAbsolutePath();

            // Validar que la extensión sea correcta.
            if (!rutaArchivo.endsWith("." + Exten1) && !rutaArchivo.endsWith("." + Exten2)) {
                rutaArchivo += "." + Exten2;
            }

            return rutaArchivo; // Devolver la ruta completa del archivo seleccionado
        } else {
            return null; // En caso de cancelar, devolver null
        }
    }

    // Método para exportar lista de usuarios a un archivo Excel
    public static void exportarAExcel(String sheetName, List<String> datosRol, String tipoRol) {
        String rutaNombreSeleccionada = guardarArchivoComo("Exportar a Excel", "Archivos Excel", "xls", "xlsx");

        if (rutaNombreSeleccionada != null) {
            Workbook workbook = new XSSFWorkbook(); // Crear el workbook
            Sheet sheet = workbook.createSheet(sheetName); // Crear la hoja con el nombre

            // Crear el estilo para el encabezado
            CellStyle estiloEncabezado = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true); // Negrita para el encabezado
            font.setColor(IndexedColors.WHITE.getIndex()); // Color blanco para el texto
            estiloEncabezado.setFont(font);

            // Color de fondo azul claro para el encabezado
            estiloEncabezado.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            estiloEncabezado.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Crear fila de encabezado y aplicar el estilo
            Row encabezado = sheet.createRow(0);

            // Dependiendo del tipo de rol, configurar los encabezados y la cantidad de columnas
            switch (tipoRol) {
                case "Estudiante":
                    encabezado.createCell(0).setCellValue("Tipo de Identidad");
                    encabezado.createCell(1).setCellValue("Cedula");
                    encabezado.createCell(2).setCellValue("Nombre");
                    encabezado.createCell(3).setCellValue("Carrera");
                    break;
                case "Docente":
                case "Administrativo":
                    encabezado.createCell(0).setCellValue("Tipo de Identidad");
                    encabezado.createCell(1).setCellValue("Cedula");
                    encabezado.createCell(2).setCellValue("Nombre");
                    encabezado.createCell(3).setCellValue("Area");
                    break;
                case "Visitante":
                    encabezado.createCell(0).setCellValue("Tipo de Identidad");
                    encabezado.createCell(1).setCellValue("ID Guardado");
                    encabezado.createCell(2).setCellValue("Nombre");
                    encabezado.createCell(3).setCellValue("Area");
                    encabezado.createCell(4).setCellValue("Motivo");
                    break;
                case "Graduado":
                    encabezado.createCell(0).setCellValue("Tipo de Identidad");
                    encabezado.createCell(1).setCellValue("Cedula");
                    encabezado.createCell(2).setCellValue("Nombre");
                    encabezado.createCell(3).setCellValue("Carrera");
                    break;
                default:
                    break;
            }

            // Aplicar estilo a las celdas del encabezado
            for (int i = 0; i < encabezado.getPhysicalNumberOfCells(); i++) {
                encabezado.getCell(i).setCellStyle(estiloEncabezado);
            }

            // Crear mapas para contar los totales por carrera o área
            Map<String, Integer> contadorCarreras = new HashMap<>();
            Map<String, Integer> contadorAreas = new HashMap<>();
            int totalPersonas = 0;

            // Llenar la hoja con los datos
            int i = 0;
            for (String datosUsuario : datosRol) {
                String[] datos = datosUsuario.split(", ");
                Row row = sheet.createRow(i + 1);

                switch (tipoRol) {
                    case "Estudiante":
                        row.createCell(0).setCellValue(datos[0]);
                        row.createCell(1).setCellValue(datos[1]);
                        row.createCell(2).setCellValue(datos[2]);
                        row.createCell(3).setCellValue(datos[3]);
                        // Contar personas por carrera
                        contadorCarreras.put(datos[3], contadorCarreras.getOrDefault(datos[3], 0) + 1);
                        break;
                    case "Docente":
                    case "Administrativo":
                        row.createCell(0).setCellValue(datos[0]);
                        row.createCell(1).setCellValue(datos[1]);
                        row.createCell(2).setCellValue(datos[2]);
                        row.createCell(3).setCellValue(datos[3]);
                        // Contar personas por área
                        contadorAreas.put(datos[3], contadorAreas.getOrDefault(datos[3], 0) + 1);
                        break;
                    case "Visitante":
                        row.createCell(0).setCellValue(datos[0]);
                        row.createCell(1).setCellValue(datos[1]);
                        row.createCell(2).setCellValue(datos[2]);
                        row.createCell(3).setCellValue(datos[3]);
                        row.createCell(4).setCellValue(datos[4]);
                        break;
                    case "Graduado":
                        row.createCell(0).setCellValue(datos[0]);
                        row.createCell(1).setCellValue(datos[1]);
                        row.createCell(2).setCellValue(datos[2]);
                        row.createCell(3).setCellValue(datos[3]);
                        // Contar personas por carrera
                        contadorCarreras.put(datos[3], contadorCarreras.getOrDefault(datos[3], 0) + 1);
                        break;
                    default:
                        break;
                }
                totalPersonas++; // Aumentamos el total de personas
                i++;
            }

            // Añadir los totales al final
            Row filaTotales = sheet.createRow(i + 1);
            filaTotales.createCell(0).setCellValue("Totales de Personas");
            filaTotales.createCell(1).setCellValue(totalPersonas);

            // Añadir la sección de carreras
            if (tipoRol.equals("Estudiante") || tipoRol.equals("Graduado")) {
                i++; // Avanzar fila para las carreras
                for (Map.Entry<String, Integer> entry : contadorCarreras.entrySet()) {
                    Row filaCarrera = sheet.createRow(i + 1);
                    filaCarrera.createCell(0).setCellValue("Carrera");
                    filaCarrera.createCell(1).setCellValue(entry.getKey());
                    filaCarrera.createCell(2).setCellValue(entry.getValue());
                    i++;
                }
            }

            // Añadir la sección de áreas
            if (tipoRol.equals("Docente") || tipoRol.equals("Administrativo")) {
                i++; // Avanzar fila para las áreas
                for (Map.Entry<String, Integer> entry : contadorAreas.entrySet()) {
                    Row filaArea = sheet.createRow(i + 1);
                    filaArea.createCell(0).setCellValue("Área");
                    filaArea.createCell(1).setCellValue(entry.getKey());
                    filaArea.createCell(2).setCellValue(entry.getValue());
                    i++;
                }
            }

            // Ajustar el tamaño de las columnas
            for (int j = 0; j < encabezado.getPhysicalNumberOfCells(); j++) {
                sheet.autoSizeColumn(j);
            }

            // Guardar el archivo
            try (FileOutputStream fileOut = new FileOutputStream(rutaNombreSeleccionada)) {
                workbook.write(fileOut);
                workbook.close();
                JOptionPane.showMessageDialog(null, "Archivo Excel creado exitosamente", "Exportando a Excel", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al crear el archivo Excel: " + e.getMessage(), "Exportando a Excel", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un archivo válido...", "Exportando a Excel", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void exportarAExcelConEncabezados(Date fechaInicial, Date fechaFinal) throws IOException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        String fechaInicio = formatoFecha.format(fechaInicial);
        String fechaFin = formatoFecha.format(fechaFinal);

        // Crear mapa para los datos
        Map<String, Map<String, Integer>> informePorFecha = new TreeMap<>();
        Map<String, Integer> totalPorFecha = new TreeMap<>();
        Map<String, Integer> totalPorHora = new TreeMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                String fechaRegistro = partes[1];
                String horaIngreso = partes[2];

                if (fechaRegistro.compareTo(fechaInicio) >= 0 && fechaRegistro.compareTo(fechaFin) <= 0) {
                    Map<String, Integer> conteoPorHora = informePorFecha.getOrDefault(fechaRegistro, new TreeMap<>());
                    conteoPorHora.merge(horaIngreso, 1, Integer::sum);
                    informePorFecha.put(fechaRegistro, conteoPorHora);
                    totalPorFecha.merge(fechaRegistro, 1, Integer::sum);
                    totalPorHora.merge(horaIngreso, 1, Integer::sum);
                }
            }
        }

        // Crear archivo Excel
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Horas Más Activas");

        // Estilo para encabezado
        CellStyle estiloEncabezado = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        estiloEncabezado.setFont(font);
        estiloEncabezado.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        estiloEncabezado.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // Encabezados dinámicos
        Row encabezado = sheet.createRow(0);
        if (fechaInicio.equals(fechaFin)) {
            encabezado.createCell(0).setCellValue("Hora");
            encabezado.createCell(1).setCellValue("Cantidad de Ingresos");
        } else {
            encabezado.createCell(0).setCellValue("Fecha");
            encabezado.createCell(1).setCellValue("Total Ingresos");
            encabezado.createCell(2).setCellValue("Hora más Activa");
            encabezado.createCell(3).setCellValue("Ingresos en Hora Pico");
        }
        for (int i = 0; i < encabezado.getLastCellNum(); i++) {
            encabezado.getCell(i).setCellStyle(estiloEncabezado);
        }

        // Llenar datos en función del rango
        int rowIndex = 1;
        if (fechaInicio.equals(fechaFin)) {
            Map<String, Integer> horasDelDia = informePorFecha.get(fechaInicio);
            if (horasDelDia != null) {
                for (Map.Entry<String, Integer> entry : horasDelDia.entrySet()) {
                    Row row = sheet.createRow(rowIndex++);
                    row.createCell(0).setCellValue(entry.getKey());
                    row.createCell(1).setCellValue(entry.getValue());
                }
            }
        } else {
            for (Map.Entry<String, Map<String, Integer>> entry : informePorFecha.entrySet()) {
                String fecha = entry.getKey();
                int totalDia = totalPorFecha.get(fecha);
                Map.Entry<String, Integer> horaMasActiva = entry.getValue().entrySet().stream()
                        .max(Map.Entry.comparingByValue())
                        .orElse(null);

                if (horaMasActiva != null) {
                    Row row = sheet.createRow(rowIndex++);
                    row.createCell(0).setCellValue(fecha);
                    row.createCell(1).setCellValue(totalDia);
                    row.createCell(2).setCellValue(horaMasActiva.getKey());
                    row.createCell(3).setCellValue(horaMasActiva.getValue());
                }
            }
        }

        // Ajustar ancho de columnas
        for (int i = 0; i < encabezado.getLastCellNum(); i++) {
            sheet.autoSizeColumn(i);
        }

        // Guardar archivo
        String fileName = guardarArchivoComo("Guardar Informe Horas Más Activas", "Archivos Excel", "xlsx", "xlsx");
        if (fileName != null) {
            try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
                workbook.write(fileOut);
                JOptionPane.showMessageDialog(null, "Archivo Excel creado exitosamente", "Exportación a Excel", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Exportación cancelada", "Exportación a Excel", JOptionPane.WARNING_MESSAGE);
        }

        workbook.close();
    }

    public static void exportarExcelSoloCantidadYFecha(List<String> registros, String fechaInicial, String fechaFinal) throws IOException {
        // Crear un archivo Excel en formato .xlsx
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Informe de Visitas");

        // Estilo para el encabezado
        CellStyle estiloEncabezado = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        estiloEncabezado.setFont(font);
        estiloEncabezado.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        estiloEncabezado.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // Crear encabezado de columnas
        Row encabezado = sheet.createRow(0);
        encabezado.createCell(0).setCellValue("Fecha");
        encabezado.createCell(1).setCellValue("Cantidad de Personas");

        // Aplicar estilo al encabezado
        for (int i = 0; i < 2; i++) {
            encabezado.getCell(i).setCellStyle(estiloEncabezado);
        }

        // Crear un mapa para contar la cantidad de registros por fecha
        Map<String, Integer> registrosPorFecha = new HashMap<>();

        // Contar cuántos registros hay para cada fecha
        for (String registro : registros) {
            String[] partes = registro.split(", ");
            String fecha = partes[5]; // Fecha en el índice 5
            registrosPorFecha.put(fecha, registrosPorFecha.getOrDefault(fecha, 0) + 1);
        }

        // Llenar la hoja con los datos
        int rowIndex = 1;
        for (Map.Entry<String, Integer> entry : registrosPorFecha.entrySet()) {
            String fecha = entry.getKey();
            int cantidad = entry.getValue();
            Row row = sheet.createRow(rowIndex++);

            // Rellenar las celdas con la fecha y la cantidad de personas
            row.createCell(0).setCellValue(fecha); // Fecha
            row.createCell(1).setCellValue(cantidad); // Cantidad de personas
        }

        // Ajustar ancho de columnas
        for (int i = 0; i < 2; i++) {
            sheet.autoSizeColumn(i);
        }

        // Llamar a guardarArchivoComo para obtener la ruta de guardado
        String fileName = guardarArchivoComo("Guardar Informe de Visitas", "Archivos Excel", "xlsx", "xlsx");

        if (fileName != null) {
            // Asegúrate de que la ruta sea válida y tenga la extensión correcta
            try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
                workbook.write(fileOut);
                JOptionPane.showMessageDialog(null, "Archivo Excel creado exitosamente", "Exportando a Excel", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al crear el archivo Excel: " + e.getMessage(), "Exportando a Excel", JOptionPane.ERROR_MESSAGE);
            } finally {
                workbook.close();  // Asegúrate de cerrar el workbook al finalizar
            }
        } else {
            JOptionPane.showMessageDialog(null, "Exportación cancelada", "Exportando a Excel", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void exportarPDFVisitantes(List<String> registros, String fechaInicialStr, String fechaFinalStr) throws DocumentException {
        // Ruta donde se guardará el archivo PDF
        String rutaNombreSeleccionada = guardarArchivoComo("Exportar a PDF", "Archivos PDF", "pdf", "pdf");

        if (rutaNombreSeleccionada != null) {
            Document Documento = new Document();
            try {
                PdfWriter.getInstance(Documento, new FileOutputStream(rutaNombreSeleccionada));
                Documento.open();

                // Ruta del logo (ajústala a la ubicación correcta del archivo de imagen)
                String logoPath = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\LogoUCP.jpg"; // Reemplaza esto con la ruta correcta
                Image logo = Image.getInstance(logoPath);

                // Escalar el logo y centrarlo
                logo.scaleToFit(200, 200);  // Ajusta el tamaño del logo según prefieras
                logo.setAlignment(Element.ALIGN_CENTER);

                // Agregar el logo al documento
                Documento.add(logo);

                // Agregar un espacio después del logo
                Documento.add(new Paragraph("\n"));

                // Crear y agregar el título "LISTADO DE REGISTROS"
                Paragraph titulo = new Paragraph("LISTADO DE REGISTROS", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14));
                titulo.setAlignment(Element.ALIGN_CENTER); // Centrar el título
                Documento.add(titulo);

                // Agregar otro espacio después del título
                Documento.add(new Paragraph("\n"));

                // Crear la tabla del encabezado
                PdfPTable encabezadoTabla = new PdfPTable(2); // 2 columnas
                encabezadoTabla.setWidthPercentage(100); // Ancho completo de la página
                encabezadoTabla.setSpacingBefore(10f); // Espacio antes de la tabla

                encabezadoTabla.addCell("Fecha");
                encabezadoTabla.addCell("Personas inscritas");

                Documento.add(encabezadoTabla); // Añadir el encabezado de la tabla al documento PDF 

                // Contar las personas registradas por fecha
                Map<String, Integer> registroPorFecha = new HashMap<>();

                // Leer los registros desde el archivo plano (VisitantesDB.txt)
                try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\ArchivosPlanos\\VisitantesDB.txt"))) {
                    String linea;
                    while ((linea = br.readLine()) != null) {
                        String[] datos = linea.split(", "); // Asumiendo que las partes están separadas por comas
                        if (datos.length < 7) { // Verificar que hay suficientes datos
                            continue; // Si no hay suficientes datos, saltamos esta línea
                        }
                        String fecha = datos[5]; // La fecha está en la posición 6 (índice 5)

                        // Incrementar el contador de registros para esa fecha
                        registroPorFecha.put(fecha, registroPorFecha.getOrDefault(fecha, 0) + 1);
                    }
                }

                // Crear la tabla de datos
                PdfPTable cuerpoTabla = new PdfPTable(2); // 2 columnas
                cuerpoTabla.setWidthPercentage(100); // Ancho completo de la página
                cuerpoTabla.setSpacingBefore(10f); // Espacio antes de la tabla

                // Agregar los datos de la tabla, solo una fila por fecha
                for (Map.Entry<String, Integer> entry : registroPorFecha.entrySet()) {
                    String fecha = entry.getKey();
                    Integer cantidad = entry.getValue();

                    // Agregar la fila con la fecha y la cantidad de personas inscritas
                    cuerpoTabla.addCell(fecha); // Fecha
                    cuerpoTabla.addCell(String.valueOf(cantidad)); // Cantidad de personas registradas
                }

                Documento.add(cuerpoTabla); // Añadir la tabla al documento PDF

                // Agregar un espacio después de la tabla
                Documento.add(new Paragraph("\n"));

                // Agregar pie de página solo al final del documento - Footer
                String fechaHoraActual = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
                String footerTexto = String.format("Impreso el: %s, :: TDS - Estructuras de Datos - Semestre II - Proyecto Control Ingreso y Salida.", fechaHoraActual);
                Paragraph footerText = new Paragraph(footerTexto, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
                footerText.setAlignment(Element.ALIGN_CENTER);
                footerText.setSpacingBefore(20);
                Documento.add(footerText);

                JOptionPane.showMessageDialog(null, "Archivo PDF creado exitosamente", "Exportando a PDF", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al crear el archivo PDF: " + e.getMessage(), "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
            } finally {
                Documento.close();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un archivo válido...", "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void exportarPDFTipoDeUsuarios(List<String> registros, String titulo, String rol) throws DocumentException {
        String rutaNombreSeleccionada = guardarArchivoComo("Exportar a PDF", "Archivos PDF", "pdf", "pdf");

        if (rutaNombreSeleccionada != null) {
            Document documento = new Document();
            try {
                PdfWriter.getInstance(documento, new FileOutputStream(rutaNombreSeleccionada));
                documento.open();

                // Validar la ruta del logo
                String logoPath = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\LogoUCP.jpg";
                File logoFile = new File(logoPath);
                if (!logoFile.exists()) {
                    throw new Exception("El logo no se encuentra en la ruta especificada: " + logoPath);
                }
                Image logo = Image.getInstance(logoPath);
                logo.scaleToFit(200, 200);
                logo.setAlignment(Element.ALIGN_CENTER);
                documento.add(logo);

                documento.add(new Paragraph("\n"));

                // Título y subtítulo
                Paragraph tituloPDF = new Paragraph(titulo, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14));
                tituloPDF.setAlignment(Element.ALIGN_CENTER);
                documento.add(tituloPDF);

                Paragraph subtituloPDF = new Paragraph("Rol: " + rol, FontFactory.getFont(FontFactory.HELVETICA, 12));
                subtituloPDF.setAlignment(Element.ALIGN_CENTER);
                documento.add(subtituloPDF);

                documento.add(new Paragraph("\n"));

                // Crear tabla
                PdfPTable tabla = null;

                if (rol.equalsIgnoreCase("Estudiante")) {
                    tabla = new PdfPTable(4);
                    tabla.addCell("Tipo de Identidad");
                    tabla.addCell("Cédula");
                    tabla.addCell("Nombre");
                    tabla.addCell("Carrera");
                } else if (rol.equalsIgnoreCase("Docente") || rol.equalsIgnoreCase("Administrativo")) {
                    tabla = new PdfPTable(4);
                    tabla.addCell("Tipo de Identidad");
                    tabla.addCell("Cédula");
                    tabla.addCell("Nombre");
                    tabla.addCell("Área");
                } else if (rol.equalsIgnoreCase("Visitante")) {
                    tabla = new PdfPTable(5); // Tabla con 6 columnas para Visitantes
                    tabla.addCell("Tipo de Identidad");
                    tabla.addCell("ID Guardado");
                    tabla.addCell("Nombre");
                    tabla.addCell("Area");
                    tabla.addCell("Motivo");
                } else if (rol.equalsIgnoreCase("Graduado")) {
                    tabla = new PdfPTable(4);
                    tabla.addCell("Tipo de Identidad");
                    tabla.addCell("Cédula");
                    tabla.addCell("Nombre");
                    tabla.addCell("Carrera");
                }

                if (tabla == null) {
                    throw new Exception("Rol no válido: " + rol);
                }

                if (rol.equalsIgnoreCase("Estudiante")) {
                    for (String datosUsuario : RegistroQR.EstudiantesDB) {
                        String[] Datos = datosUsuario.split(", ");
                        tabla.addCell(Datos[0]);
                        tabla.addCell(Datos[1]);
                        tabla.addCell(Datos[2]);
                        tabla.addCell(Datos[3]);
                    }
                } else {
                    if (rol.equalsIgnoreCase("Docente")) {
                        for (String datosUsuario : RegistroQR.DocentesDB) {
                            String[] Datos = datosUsuario.split(", ");
                            tabla.addCell(Datos[0]);
                            tabla.addCell(Datos[1]);
                            tabla.addCell(Datos[2]);
                            tabla.addCell(Datos[3]);
                        }
                    } else {
                        if (rol.equalsIgnoreCase("Adminitrativo")) {
                            for (String datosUsuario : RegistroQR.AdministrativosDB) {
                                String[] Datos = datosUsuario.split(", ");
                                tabla.addCell(Datos[0]);
                                tabla.addCell(Datos[1]);
                                tabla.addCell(Datos[2]);
                                tabla.addCell(Datos[3]);
                            }
                        } else {
                            if (rol.equalsIgnoreCase("Visitante")) {
                                for (String datosUsuario : RegistroQR.VisitantesDB) {
                                    String[] Datos = datosUsuario.split(", ");
                                    tabla.addCell(Datos[0]);
                                    tabla.addCell(Datos[1]);
                                    tabla.addCell(Datos[2]);
                                    tabla.addCell(Datos[3]);
                                    tabla.addCell(Datos[4]);
                                }
                            } else {
                                if (rol.equalsIgnoreCase("Graduado")) {
                                    for (String datosUsuario : RegistroQR.GraduadosDB) {
                                        String[] Datos = datosUsuario.split(", ");
                                        tabla.addCell(Datos[0]);
                                        tabla.addCell(Datos[1]);
                                        tabla.addCell(Datos[2]);
                                        tabla.addCell(Datos[3]);
                                    }
                                }
                            }
                        }
                    }
                }

                documento.add(tabla);
                documento.add(new Paragraph("\n"));

                String fechaHoraActual = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
                Paragraph footer = new Paragraph("Impreso el: " + fechaHoraActual + ", :: Proyecto de Control Ingreso y Salida.",
                        FontFactory.getFont(FontFactory.HELVETICA, 8));
                footer.setAlignment(Element.ALIGN_CENTER);
                footer.setSpacingBefore(20);
                documento.add(footer);

                JOptionPane.showMessageDialog(null, "Archivo PDF creado exitosamente", "Exportando a PDF", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al crear el archivo PDF: " + e.getMessage(), "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
            } finally {
                documento.close();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un archivo válido...", "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void exportarAPDFHoras(Date fechaInicial, Date fechaFinal) throws DocumentException {
        // Formato de fecha para las comparaciones y la presentación
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        String fechaInicio = formatoFecha.format(fechaInicial);
        String fechaFin = formatoFecha.format(fechaFinal);

        // Estructuras para almacenar el conteo por fecha y hora
        Map<String, Map<String, Integer>> informePorFecha = new TreeMap<>();
        Map<String, Integer> totalPorFecha = new TreeMap<>();
        Map<String, Integer> totalPorHora = new TreeMap<>();

        // Leer el archivo de registros
        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IngresoYSalidaAP\\IngresosSalidasDB.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                String fechaRegistro = partes[1];
                String horaIngreso = partes[2].substring(0, 5); // Extraemos la hora sin los segundos

                // Filtrar los registros por el rango de fechas
                if (fechaRegistro.compareTo(fechaInicio) >= 0 && fechaRegistro.compareTo(fechaFin) <= 0) {
                    // Contar los ingresos por hora y fecha
                    Map<String, Integer> conteoPorHora = informePorFecha.getOrDefault(fechaRegistro, new TreeMap<>());
                    conteoPorHora.merge(horaIngreso, 1, Integer::sum);
                    informePorFecha.put(fechaRegistro, conteoPorHora);
                    totalPorFecha.merge(fechaRegistro, 1, Integer::sum);
                    totalPorHora.merge(horaIngreso, 1, Integer::sum);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de registros", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Seleccionar la ubicación donde guardar el archivo PDF
        String rutaNombreSeleccionada = guardarArchivoComo("Exportar a PDF", "Archivos PDF", "pdf", "pdf");
        if (rutaNombreSeleccionada != null) {
            Document documento = new Document();
            try {
                PdfWriter.getInstance(documento, new FileOutputStream(rutaNombreSeleccionada));
                documento.open();

                // Agregar título al documento
                String logoPath = "C:\\Users\\usuario\\OneDrive\\Desktop\\PROYECTO COMPLETO\\RegistroQR\\src\\main\\java\\IMG UCP\\LogoUCP.jpg"; // Reemplaza esto con la ruta correcta
                Image logo = Image.getInstance(logoPath);

                // Escalar el logo y centrarlo
                logo.scaleToFit(200, 200);  // Ajusta el tamaño del logo según prefieras
                logo.setAlignment(Element.ALIGN_CENTER);

                // Agregar el logo al documento
                documento.add(logo);

                // Agregar un espacio después del logo
                documento.add(new Paragraph("\n"));

                // Crear y agregar el título "LISTADO DE REGISTROS"
                Paragraph titulo = new Paragraph("LISTADO DE REGISTROS", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14));
                titulo.setAlignment(Element.ALIGN_CENTER); // Centrar el título
                documento.add(titulo);

                // Agregar otro espacio después del título
                documento.add(new Paragraph("\n"));
                documento.add(new Paragraph("\n"));

                // Crear la tabla con los datos
                PdfPTable tabla = new PdfPTable(4);  // Fecha, Hora, Cantidad, Top 3

                // Encabezados de la tabla
                tabla.addCell("Fecha");
                tabla.addCell("Hora");
                tabla.addCell("Cantidad de Personas");
                tabla.addCell("Hora Más Activa");

                // Agregar los registros por fecha y hora
                for (Map.Entry<String, Map<String, Integer>> entry : informePorFecha.entrySet()) {
                    String fecha = entry.getKey();
                    Map<String, Integer> horasDelDia = entry.getValue();

                    // Encontrar la hora más activa
                    Map.Entry<String, Integer> horaMasActiva = horasDelDia.entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .orElse(null);

                    if (horaMasActiva != null) {
                        // Agregar los datos de la fecha y hora
                        for (Map.Entry<String, Integer> horaEntry : horasDelDia.entrySet()) {
                            tabla.addCell(fecha);
                            tabla.addCell(horaEntry.getKey());
                            tabla.addCell(String.valueOf(horaEntry.getValue()));
                            tabla.addCell(horaMasActiva.getKey() + " - " + horaMasActiva.getValue() + " ingresos");
                        }
                    }
                }

                // Agregar la tabla al documento
                documento.add(tabla);

                // Agregar la fecha y hora de creación del documento
                String fechaHoraActual = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
                String footerTexto = String.format("Impreso el: %s, :: TDS - Estructuras de Datos - Semestre II - Proyecto Control Ingreso y Salida.", fechaHoraActual);
                Paragraph footerText = new Paragraph(footerTexto, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
                footerText.setAlignment(Element.ALIGN_CENTER);
                footerText.setSpacingBefore(20);
                documento.add(footerText);


                JOptionPane.showMessageDialog(null, "Archivo PDF creado exitosamente", "Exportando a PDF", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al crear el archivo PDF: " + e.getMessage(), "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
            } finally {
                documento.close();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un archivo válido...", "Exportando a PDF", JOptionPane.ERROR_MESSAGE);
        }
    }

}
